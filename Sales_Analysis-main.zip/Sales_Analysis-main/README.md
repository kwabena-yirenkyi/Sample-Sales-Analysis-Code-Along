# Sales_Analysis
Analyzing commercial data from a sample data frame
Some Queries used on Sales Data frames
